/*ODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include"string.h"
#include <stdbool.h>
#include<HC595.h>
#include<storage.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
uint8_t uart1RxData[UART_RX_BUF_SIZE];
uint8_t uart2RxData[UART_RX_BUF_SIZE];
uint8_t *ptr;
int cnt=0;
uint8_t slave_id=0x01;
uint32_t selectedBaudRate=9600;
uint8_t uart2_rx_byte;
uint8_t uart1_rx_byte;
static uint16_t uart1rxcount=0;
static uint16_t uart2rxcount=0;
uint8_t adc_conversion_mode[8]={4,4,4,4,4,4,4,4};//V0_10
static int cmd_cnt=0;
int32_t raw1,raw2,raw3;
uint8_t status;
float voltageReading0,voltageReading2,result_temp=0.0;
uint8_t data[UART_RX_BUF_SIZE];
uint32_t indx=0;
uint16_t uart1crc;
uint16_t uart2crc;

eMode_t conversion_mode,conversion_mode1=0;

float supply[8];

const MapEntry configMap[] = {
	{0,MV0_50},
    {1, MV0_100},
	{2, MV0_250},
    {3, V0_5},
    {4, V0_10},
    {5,MA4_20},
	{6,MA0_20},
};

#define ICNT 1

flash_t W_flash={.channalmode={4,4,4,4,4,4,4,4},
		.BaudRate=9600,
		.SlaveID=0x01,
};

flash_t R_flash={.channalmode={4,4,4,4,4,4,4,4},
		.BaudRate=9600,
		.SlaveID=0x01,
};

uint32_t Holding_Registers_Database[100]={0};
RingBuffer_t uart2_rx_rb = { .head = 0, .tail = 0 };
RingBuffer_t uart1_rx_rb = { .head = 0, .tail = 0 };

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
void PollUartBaudRate(void)
{
	uint8_t gpioVal = (HAL_GPIO_ReadPin(BAUD1_GPIO_Port, BAUD1_Pin) << 1) |
	HAL_GPIO_ReadPin(BAUD2_GPIO_Port, BAUD2_Pin);
	static uint32_t prevBaudRate;

	switch (gpioVal)
	{
		case BAUD_9600: selectedBaudRate = 9600; break;
		case BAUD_19200: selectedBaudRate = 19200; break;
		case BAUD_38400: selectedBaudRate = 38400; break;
		case BAUD_115200:selectedBaudRate = 115200; break;
		default: selectedBaudRate = 115200; break;
	}
//	selectedBaudRate=9600;
	 W_flash.BaudRate=selectedBaudRate;

//	 if(W_flash.BaudRate!=R_flash.BaudRate){
//		 Flash_WriteSettings(&W_flash);
//	 }
//	 Flash_ReadSettings(&R_flash);
//	 selectedBaudRate=R_flash.BaudRate;
	// Change baud only if different from previous
	if (selectedBaudRate != prevBaudRate)
	{
		prevBaudRate = selectedBaudRate;

		/* -------- UART3 -------- */
		HAL_UART_AbortReceive(&huart2);
		HAL_Delay(2);
		HAL_UART_DeInit(&huart2);
		huart2.Init.BaudRate = selectedBaudRate;
		HAL_UART_Init(&huart2);
		HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);

		/* -------- UART1 -------- */
		HAL_UART_AbortReceive(&huart1);
		HAL_Delay(2);
		HAL_UART_DeInit(&huart1);
		huart1.Init.BaudRate = selectedBaudRate;
		HAL_UART_Init(&huart1);
		HAL_UART_Receive_IT(&huart1, &uart1_rx_byte, 1);

	}
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
eMode_t check_and_get_adc_conversion_mode(uint8_t *conversion_mode,channal_t channal){


	for(int i=0;i<sizeof(configMap)/sizeof(MapEntry);i++){
				if(configMap[i].regValue==conversion_mode[channal])
					return configMap[i].config;// set channal on the basis of conversion_mode value

		}
		return configMap[channal].config;//default setting if conversion_mode is mismatch with regValue
}






uint16_t enbit=0;
void set_adc_conversion_mode(uint8_t *conversion_mode){

	for(uint8_t channal=0;channal<8;channal++){
		for(int i=0;i<sizeof(configMap)/sizeof(MapEntry);i++){
					if(configMap[i].regValue==conversion_mode[channal]){
						switch(configMap[i].config){
							case V0_5:
								 enbit |=(1<<channal);//i is bit position set i position bit
								break;
							case V0_10 :
								enbit |=(1<<channal);
								break;

							case MV0_50:
								enbit &=~(1<<channal);//clear i position bit
								break;
							case MV0_100:
								enbit &=~(1<<channal);
								break;
							case MV0_250 :
								enbit &=~(1<<channal);
								break;
							case MA0_20:
								enbit |=(1<<channal);
								break;
							case MA4_20 :
								enbit |=(1<<channal);
								break;

						}

					}

			}
	}
	input_high(enbit);
}





void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance==USART2){
		uint16_t next = (uart2_rx_rb.head + 1) % UART_RX_BUF_SIZE;
		if (next != uart2_rx_rb.tail) {   // buffer not full
			uart2_rx_rb.buffer[uart2_rx_rb.head] = uart2_rx_byte;
			uart2_rx_rb.head = next;
		}
		// Restart interrupt
		HAL_UART_Receive_IT(huart, &uart2_rx_byte, 1);
	}
	else if(huart->Instance==USART1){
		uint16_t next = (uart1_rx_rb.head + 1) % UART_RX_BUF_SIZE;
		if (next != uart1_rx_rb.tail) {   // buffer not full
			uart1_rx_rb.buffer[uart1_rx_rb.head] = uart1_rx_byte;
			uart1_rx_rb.head = next;
		}
		// Restart interrupt
		HAL_UART_Receive_IT(huart, &uart1_rx_byte, 1);

	}
}


uint16_t RingBuffer_GetCount(RingBuffer_t *rb)
{
    if (rb->head >= rb->tail)
        return rb->head - rb->tail;
    else
        return UART_RX_BUF_SIZE - rb->tail + rb->head;
}

int RingBuffer_Read(RingBuffer_t* rb, uint8_t* out)
{
    if (rb->head == rb->tail) return 0;

    *out = rb->buffer[rb->tail];
    rb->tail = (rb->tail + 1) % UART_RX_BUF_SIZE;
    return 1;
}
uint8_t reglen;
uint8_t tx_[MIN_CMD_LEN];
static uint16_t uart1len = 0;
static uint16_t uart2len = 0;
//bool read_multi_reg(UART_HandleTypeDef *uartx){
//
//	    // Minimum required bytes
//	    if(len < MIN_CMD_LEN)
//	        return false;
//
//	    // Extract CRC from last two bytes
//	    uint16_t crc_recv = (RxData[len-1]<<8)|RxData[len-2];
//	    uint16_t crc_calc = crc16(RxData, len - 2);
//	    reglen=len;
//	    // Validate Modbus frame
//	    if(RxData[0] != slave_id)    return false;
//	    if(RxData[1] != MB_WRITE_FC) return false;
//	    if(crc_recv != crc_calc)     return false;
//
//	    uint8_t byte_count = RxData[6];
//
//	    if(len < (7 + byte_count + 2))
//	        return false;  // incomplete frame
//
//	    memset(tx_,0,sizeof(tx_));
//		for(uint8_t i=0;i<len-2;i++){
//			tx_[i]=RxData[i];
//		}
//
//		sendData(tx_,len-2,uartx);
//	    // Copy data values
//	    uint8_t ind = 0;
//	    for(uint8_t i = 0; i < byte_count; i += 2)
//	    {
//	        adc_conversion_mode[ind++] = RxData[8 + i];
//	    }
//	//
//	    return true;
//
//}

bool read_single_reg(UART_HandleTypeDef *uartx){

	    // Minimum required bytes
	if(uartx->Instance==USART1){
	    if(uart1len < 8)
	        return false;

	    // Extract CRC from last two bytes
	    uint16_t crc_recv = (uart1RxData[uart1len-1]<<8)|uart1RxData[uart1len-2];
	    uint16_t crc_calc = crc16(uart1RxData, uart1len - 2);

	    // Validate Modbus frame
	    if(uart1RxData[0] != slave_id)    return false;
	    if(uart1RxData[1] != 0x06) return false;//function code
	    if(crc_recv != crc_calc)     return false;

	    uint8_t tx[8]={0};

	    tx[0]=uart1RxData[0];
	    tx[1]=uart1RxData[1];
	    tx[2]=uart1RxData[2];
	    tx[3]=uart1RxData[3];
	    tx[4]=uart1RxData[4];
	    tx[5]=uart1RxData[5];

	    sendData(tx,6,uartx);
	    if(uart1RxData[3]>20&&uart1RxData[3]<=28){
	    	static uint8_t all_set=0;
	    	adc_conversion_mode[uart1RxData[3]-21] = uart1RxData[5];
			if(uart1RxData[3]==21){
				HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, SET);
				all_set|=(1<<0);
			}
			else if(uart1RxData[3]==22){
				HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, SET);
				all_set|=(1<<1);
			}
			else if(uart1RxData[3]==23){
				HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, SET);
				all_set|=(1<<2);
			}
			else if(uart1RxData[3]==24){
				HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, SET);
				all_set|=(1<<3);
			}
			else if(uart1RxData[3]==25){
				HAL_GPIO_WritePin(LED5_GPIO_Port, LED5_Pin, SET);
				all_set|=(1<<4);
			}
			else if(uart1RxData[3]==26){
				HAL_GPIO_WritePin(LED6_GPIO_Port, LED6_Pin, SET);
				all_set|=(1<<5);
			}
			else if(uart1RxData[3]==27){
				HAL_GPIO_WritePin(LED8_GPIO_Port, LED8_Pin, SET);

				all_set|=(1<<6);
			}
			else if(uart1RxData[3]==28){
				HAL_GPIO_WritePin(LED7_GPIO_Port, LED7_Pin, SET);
				all_set|=(1<<7);
			}
			if(uart1RxData[5]<8&&all_set==0xFF)set_is_configured();
	    }

	}
	else if(uartx->Instance==USART2){
	    if(uart2len < 8)return false;

	    // Extract CRC from last two bytes
	    uint16_t crc_recv = (uart2RxData[uart2len-1]<<8)|uart2RxData[uart2len-2];
	    uint16_t crc_calc = crc16(uart2RxData, uart2len - 2);

	    // Validate Modbus frame
	    if(uart2RxData[0] != slave_id)    return false;
	    if(uart2RxData[1] != 0x06) return false;//function code
	    if(crc_recv != crc_calc)     return false;
	    uint8_t tx[8]={0};

	    tx[0]=uart2RxData[0];
	    tx[1]=uart2RxData[1];
	    tx[2]=uart2RxData[2];
	    tx[3]=uart2RxData[3];
	    tx[4]=uart2RxData[4];
	    tx[5]=uart2RxData[5];
	    sendData(tx,6,uartx);

	    if(uart2RxData[3]>20&&uart2RxData[3]<=28){
			static uint8_t all_set=0;
			adc_conversion_mode[uart2RxData[3]-21] = uart2RxData[5];
			if(uart2RxData[3]==21){
				HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, SET);
				all_set|=(1<<0);
			}
			else if(uart2RxData[3]==22){
				HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, SET);
				all_set|=(1<<1);
			}
			else if(uart2RxData[3]==23){
				HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, SET);
				all_set|=(1<<2);
			}
			else if(uart2RxData[3]==24){
				HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, SET);
				all_set|=(1<<3);
			}
			else if(uart2RxData[3]==25){
				HAL_GPIO_WritePin(LED5_GPIO_Port, LED5_Pin, SET);
				all_set|=(1<<4);
			}
			else if(uart2RxData[3]==26){
				HAL_GPIO_WritePin(LED6_GPIO_Port, LED6_Pin, SET);
				all_set|=(1<<5);
			}
			else if(uart2RxData[3]==27){
				HAL_GPIO_WritePin(LED8_GPIO_Port, LED8_Pin, SET);

				all_set|=(1<<6);
			}
			else if(uart2RxData[3]==28){
				HAL_GPIO_WritePin(LED7_GPIO_Port, LED7_Pin, SET);
				all_set|=(1<<7);
			}
			if(uart2RxData[5]<8&&all_set==0xFF)set_is_configured();
		}
	}
	    return true;
}


bool get_adc_conversion_value(uint8_t *adc_conversion_mode,UART_HandleTypeDef *uartx){
	bool status;


	if(uartx->Instance==USART1){
		uart1len=0;
		uart1rxcount= RingBuffer_GetCount(&uart1_rx_rb);
		if(uart1rxcount == 0)
			return false;  // no data yet
		if(uart1rxcount > UART_RX_BUF_SIZE )
			uart1rxcount = UART_RX_BUF_SIZE; // prevent overflow

		 while((uart1rxcount=RingBuffer_GetCount(&uart1_rx_rb))){
			 RingBuffer_Read(&uart1_rx_rb, &uart1RxData[uart1len++]);
			 HAL_Delay(1);
		 }
	}
	else if(uartx->Instance==USART2){
		uart2len=0;

		uart2rxcount= RingBuffer_GetCount(&uart2_rx_rb);
		if(uart2rxcount==0)
			return false;  // no data yet

		if(uart2rxcount > UART_RX_BUF_SIZE )
			uart2rxcount = UART_RX_BUF_SIZE; // prevent overflow

		while((uart2rxcount=RingBuffer_GetCount(&uart2_rx_rb))){
			 RingBuffer_Read(&uart2_rx_rb, &uart2RxData[uart2len++]);
			 HAL_Delay(1);
		 }
	}
	read_single_reg(uartx)?(status =true ):(status =false);
	//read_multi_reg()?(status= true) :(status= false);

    return status;
}
int channal=0x00;
//void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
//	static int  i=0;
//
//	cnt++;
//	if(i>7){
//		channal=0;
//		i=0;
//	}
//
//	     //ADS1247_write_register(REG_MUX0,1,((channal>>1)|N_AIN7));
////		 raw1=ADS1247_ReadData(P_AIN0);
////		 sum += raw1;
////
////		raw1=sum/ICNT;
////		voltageReading0=ads1247_raw_to_voltage(raw1, 2.049, 1);
////		supply[channal_0+i]=get_supply(voltageReading0,conversion_mode1);
////		channal+=16;
//}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */


void ads_main(){
	//ADS1247_write_register(REG_MUX0,1,((channal>>1)|N_AIN7));
	//HAL_Delay(150);
//	sum=0;
//	set_adc_conversion_mode(adc_conversion_mode);
//	conversion_mode1=check_and_get_adc_conversion_mode(adc_conversion_mode,channal_0);//check channal configuration mode value and get conversion mode
		//if (HAL_GPIO_ReadPin(DRDY_PORT, DRDY_PIN) == GPIO_PIN_RESET){
		//	for(int i=0;i<ICNT;i++){
//			 raw1=ADS1247_ReadData(P_AIN0);
//			 sum += raw1;
//			}


}
int main(void)
{

  /* USER CODE BEGIN 1 */
	uint8_t buf_A=0;
	int32_t sum=0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();


  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  RST_HIGH_B();
  csHIGH_B();
  enable_MCPA_B();
  port_configA_B();
  latch_configA_B();
  enable_MCPB_B();
  port_configB_B();
  polarity_configB_B();
  latch_configB_B();

  CS_HIGH;//asd1247 cs

  ADS1247_begin();

    if(get_is_configured()==SET){
		HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, SET);
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, SET);
		HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, SET);
		HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, SET);
		HAL_GPIO_WritePin(LED5_GPIO_Port, LED5_Pin, SET);
		HAL_GPIO_WritePin(LED6_GPIO_Port, LED6_Pin, SET);
		HAL_GPIO_WritePin(LED7_GPIO_Port, LED7_Pin, SET);
		HAL_GPIO_WritePin(LED8_GPIO_Port, LED8_Pin, SET);
//
    }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  /* USER CODE BEGIN WHILE */
 	while(1){
 //		 uint8_t len=0;

 		 slave_id=GPIO_readA_B();
 		 //slave_id = buf_A;
 		 W_flash.SlaveID=slave_id;
 //
 //		 if(W_flash.SlaveID!=R_flash.SlaveID){
 //			 Flash_WriteSettings(&W_flash);
 //		 }




 		 PollUartBaudRate();//configure baudrate for mb



 		 if(true==get_adc_conversion_value(adc_conversion_mode,&huart1));
 		 if(true==get_adc_conversion_value(adc_conversion_mode,&huart2));






 		 memcpy(W_flash.channalmode,adc_conversion_mode,8);


 /*save channal configuration in flash*/
 		 if(memcmp(W_flash.channalmode,R_flash.channalmode,8)!=0/*||get_is_configured()==0*/){


 			 Flash_WriteSettings(&W_flash);
 //			 set_is_configured();
 		 }
 		 Flash_ReadSettings(&R_flash);
 		 memcpy(adc_conversion_mode,R_flash.channalmode,8);




 		channal=0;
		for(int i=0;i<7;i++){

			ADS1247_write_register(REG_MUX0,1,((channal>>1)|N_AIN7));
			sum=0;
			set_adc_conversion_mode(adc_conversion_mode);
			conversion_mode1=check_and_get_adc_conversion_mode(adc_conversion_mode,channal_0+i);//check channal configuration mode value and get conversion mode
				if (HAL_GPIO_ReadPin(DRDY_PORT, DRDY_PIN) == GPIO_PIN_RESET){
					for(int i=0;i<ICNT;i++){
					 raw1=ADS1247_ReadData(P_AIN0);
					 sum += raw1;
					}
				}
			raw1=sum/ICNT;
			voltageReading0=ads1247_raw_to_voltage(raw1, 2.5, 1);
			supply[channal_0+i]=get_supply(voltageReading0,conversion_mode1);
			 uart1crc=(uart1RxData[CRC_HIGH]<<8)|uart1RxData[CRC_LOW];
			 uart2crc=(uart2RxData[CRC_HIGH]<<8)|uart2RxData[CRC_LOW];
			 if( (uart1RxData[0]==slave_id) &&(uart1RxData[1]==0x03) &&(uart1crc==crc16(uart1RxData, CMD_LEN)) ){

				 memcpy(&Holding_Registers_Database[channal_0],&supply[channal_0],4);
				 memcpy(&Holding_Registers_Database[channal_1],&supply[channal_1],4);
				 memcpy(&Holding_Registers_Database[channal_2],&supply[channal_2],4);
				 memcpy(&Holding_Registers_Database[channal_3],&supply[channal_3],4);
				 memcpy(&Holding_Registers_Database[channal_4],&supply[channal_4],4);
				 memcpy(&Holding_Registers_Database[channal_5],&supply[channal_5],4);
				 memcpy(&Holding_Registers_Database[channal_6],&supply[channal_6],4);
				 memcpy(&Holding_Registers_Database[channal_7],&supply[channal_7],4);




				 writeHoldingRegs(UINT32_T,&huart1);
//				 cmd_cnt++;
				 memset(uart1RxData,0,sizeof(uart1RxData));

			}
			else if( (uart2RxData[0]==slave_id)&&(uart2RxData[1]==0x03)&&(uart2crc==crc16(uart2RxData, CMD_LEN)) ){

				 memcpy(&Holding_Registers_Database[channal_0],&supply[channal_0],4);
				 memcpy(&Holding_Registers_Database[channal_1],&supply[channal_1],4);
				 memcpy(&Holding_Registers_Database[channal_2],&supply[channal_2],4);
				 memcpy(&Holding_Registers_Database[channal_3],&supply[channal_3],4);
				 memcpy(&Holding_Registers_Database[channal_4],&supply[channal_4],4);
				 memcpy(&Holding_Registers_Database[channal_5],&supply[channal_5],4);
				 memcpy(&Holding_Registers_Database[channal_6],&supply[channal_6],4);
				 memcpy(&Holding_Registers_Database[channal_7],&supply[channal_7],4);

				 writeHoldingRegs(UINT32_T,&huart2);
//				 cmd_cnt++;

				 memset(uart2RxData,0,sizeof(uart2RxData));
			}
//			else if((uart1RxData[0]==slave_id)&&(uart1RxData[1]==0x06)){
//				read_single_reg(&huart1)?(status =true ):(status =false);
//			}
			channal+=16;
		}

/*******************************************************************************************************************/
 	}
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL8;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 7;
  hspi2.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi2.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 38400;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
 // HAL_UART_Receive_IT(&huart1, &uart1_rx_byte, 1);
  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 38400;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */
//  HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);
  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LED6_Pin|LED5_Pin|LED4_Pin|LED3_Pin
                          |LED2_Pin|GPIO_PIN_6|CTRL0_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED1_Pin|LED8_Pin|ADC_CS1_Pin|CTRL2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED7_GPIO_Port, LED7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, MCP_CS2_Pin|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |ADS_RESET_Pin|MCP_RST1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED6_Pin LED5_Pin LED4_Pin LED3_Pin
                           LED2_Pin PC6 CTRL0_Pin */
  GPIO_InitStruct.Pin = LED6_Pin|LED5_Pin|LED4_Pin|LED3_Pin
                          |LED2_Pin|GPIO_PIN_6|CTRL0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LED1_Pin LED8_Pin ADC_CS1_Pin CTRL2_Pin */
  GPIO_InitStruct.Pin = LED1_Pin|LED8_Pin|ADC_CS1_Pin|CTRL2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : LED7_Pin */
  GPIO_InitStruct.Pin = LED7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED7_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MCP_CS2_Pin PB3 PB4 PB5
                           ADS_RESET_Pin MCP_RST1_Pin */
  GPIO_InitStruct.Pin = MCP_CS2_Pin|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |ADS_RESET_Pin|MCP_RST1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : BAUD2_Pin BAUD1_Pin */
  GPIO_InitStruct.Pin = BAUD2_Pin|BAUD1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : DRDY_Pin */
  GPIO_InitStruct.Pin = DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DRDY_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
