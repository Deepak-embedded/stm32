
/*
 * ADS1247.c
 *
 *  Created on: Oct 13, 2025
 *      Author: Nelumbo
 */
#include"main.h"
#include<stdint.h>
#include <math.h>
extern SPI_HandleTypeDef hspi1;
uint8_t read_cmd[10];
uint8_t writecmd[10] ;
double temp=0.0;

/**
  * @brief  addr :-address of register
  * 		byte :-amount of byte need to read (read one byte)
  * 		return :- register value if sucess or -1 on fail
  */

 uint8_t ADS1247_read_register(uint8_t addr,uint8_t byte){

	  uint8_t cmd[3];
	  uint8_t val;
	  cmd[0] = CMD_RREG | addr;
	  cmd[1] = 0x00; //byte-1
	  cmd[2] = CMD_NOP;

	  CS_LOW;

	  HAL_Delay(10);
	  if(HAL_OK!=HAL_SPI_Transmit(&hspi1, cmd, 2, 1000))
		  return -1;
	  HAL_Delay(10);
	  if(HAL_OK!=HAL_SPI_TransmitReceive(&hspi1, &cmd[2], &val, 1, HAL_MAX_DELAY))
		  return -1;
	  HAL_Delay(10);

	  CS_HIGH;

	  return val;
}

 /**
   * @brief  addr :-address of register
   * 		byte :-amount of byte need to write (write one byte)
   * 		return :- HAL_OK if sucess or -1 on fail
   */

uint8_t ADS1247_write_register(uint8_t addr,uint8_t byte,uint8_t data){


	  uint8_t cmd[3];
	  cmd[0] = CMD_WREG | addr;
	  cmd[1] = 0x00;       // write 1 register
	  cmd[2] = data;

	  CS_LOW;

	  HAL_Delay(5);
	  if(HAL_OK!=HAL_SPI_Transmit(&hspi1, &cmd[0], 1, HAL_MAX_DELAY))
		  return -1;
//	  HAL_Delay(5);
	  if(HAL_OK!=HAL_SPI_Transmit(&hspi1, &cmd[1], 1, HAL_MAX_DELAY))
		  return -1;
//	  HAL_Delay(5);
	  if(HAL_OK!=HAL_SPI_Transmit(&hspi1, &cmd[2], 1, HAL_MAX_DELAY))
	  	  return -1;
//	  HAL_Delay(5);

	  CS_HIGH;

	  return HAL_OK;

}

/**
  * @brief  :- read the adc raw data
  *
  * 		return :- read adc conversion if sucess or -1 on fail
  */
int32_t ADS1247_ReadData(uint8_t channel){

  uint8_t cmd = CMD_RDATA;
  uint8_t rx[3]={0,0,0};
  int32_t value = 0;
  uint8_t tx[4]={CMD_NOP,CMD_NOP,CMD_NOP};

//  channel=(channel>>1)|N_AIN7;
//  ADS1247_write_register(REG_MUX0,1,channel);
//  HAL_Delay(10);
  CS_LOW;

  if(HAL_OK!=HAL_SPI_Transmit(&hspi1, &cmd, 1, 5000))
 // if(HAL_OK!=HAL_SPI_Transmit(&hspi1, &cmd, 1, 5))
	  return -1;
//  HAL_Delay(1);
  if(HAL_OK!=HAL_SPI_TransmitReceive(&hspi1, tx, rx, 3, HAL_MAX_DELAY))
//  if(HAL_OK!=HAL_SPI_TransmitReceive(&hspi1, tx, rx, 3, 5))
	  return -1;
//  HAL_Delay(1);

  CS_HIGH;
  value = ((int32_t)rx[0] << 16) | ((int32_t)rx[1] << 8) | rx[2];
 //  Sign extension for 24-bit data
  if (value & 0x800000)
	  value |= 0xFF000000;

  return value;
}

/**
  * @brief  :- init the adc with register
  *
  * 		return :- read adc conversion if sucess or -1 on fail
  */
void ads1247_init(adc124xx_t *conf){
	  // Reset and Start
	  RESET_LOW;
	  HAL_Delay(10);
	  RESET_HIGH;
	  HAL_Delay(10);

//	  START_HIGH;
//	  HAL_Delay(10);

	  // Stop continuous read
	  uint8_t cmd = CMD_SDATAC;
	  CS_LOW;
	  HAL_Delay(10);
	  HAL_SPI_Transmit(&hspi1, &cmd, 1, 2000);
	  HAL_Delay(10);
	  CS_HIGH;
	  HAL_Delay(1000);

	  if((conf->sel_channel_P==P_AIN0 || conf->sel_channel_P>=P_AIN1 || conf->sel_channel_P<=P_AINCOM)
			  && (conf->sel_channel_N== N_AIN0||conf->sel_channel_N>=N_AIN1||conf->sel_channel_N<=N_AIN1)){
		  ADS1247_write_register(REG_MUX0,1, conf->sel_channel_P|conf->sel_channel_N);
	  }HAL_Delay(10);

	  if(conf->sel_bias==EN_BIAS_AIN0 || conf->sel_bias==EN_BIAS_AIN1 ||conf->sel_bias==EN_BIAS_AIN2 || conf->sel_bias==EN_BIAS_AIN3 || conf->sel_bias==DIS_BIAS_AINx){
		  ADS1247_write_register(REG_VBIAS,1, conf->sel_bias);
	  }HAL_Delay(10);

	  if((conf->sel_dr>=DOR3_5 || conf->sel_dr<=DOR3_2000) && (conf->sel_pga>=PGA2_0 || conf->sel_pga<=PGA2_128)){
		  ADS1247_write_register(REG_SYS0,1, conf->sel_dr|conf->sel_pga);
	  }HAL_Delay(10);

	  if(conf->sel_exc_mag>=IMAG2_OFF || conf->sel_exc_mag<=IMAG2_1500){
		  ADS1247_write_register(REG_IDAC0,1, conf->sel_exc_mag);
	  }HAL_Delay(10);

	  if(conf->sel_exc_out==I1DIR_AIN0 ||conf->sel_exc_out==I1DIR_AIN1 || conf->sel_exc_out==I1DIR_AIN2 ||conf->sel_exc_out==I1DIR_AIN3 ||conf->sel_exc_out==I1DIR_OFF){
		  ADS1247_write_register(REG_IDAC1,1, conf->sel_exc_out);
	  }HAL_Delay(10);

	  if((conf->sel_sys_moniter>=MUXCAL2_NORMAL||conf->sel_sys_moniter<=MUXCAL2_DVDD)
			  && (conf->sel_internal_ref ==VREFCON1_OFF || conf->sel_internal_ref ==VREFCON1_ON ||conf->sel_internal_ref ==VREFCON1_PS)
			  && (conf->sel_ref==REFSELT1_REF0 ||conf->sel_ref==REFSELT1_REF1 ||conf->sel_ref==REFSELT1_ON ||conf->sel_ref==REFSELT1_ON_REF0)){
		  ADS1247_write_register(REG_MUX1,1, conf->sel_sys_moniter|conf->sel_internal_ref|conf->sel_ref);
	  }HAL_Delay(10);






}

void ADS1247_begin(void){
	  // Reset and Start
	  RESET_LOW;
	  HAL_Delay(10);
	  RESET_HIGH;
	  HAL_Delay(10);
//
////	  START_HIGH;
////	  HAL_Delay(10);
//
	  HAL_Delay(1000);
	  uint8_t cmd=CMD_RESET;
	  CS_LOW;
	  HAL_Delay(10);
	  HAL_SPI_Transmit(&hspi1, &cmd, 1, 2000);
	  HAL_Delay(10);
	  CS_HIGH;
	  HAL_Delay(1000);
	  // Stop continuous read
	  cmd = CMD_SDATAC;
	  CS_LOW;
	  HAL_Delay(10);
	  HAL_SPI_Transmit(&hspi1, &cmd, 1, 2000);
	  HAL_Delay(10);
	  CS_HIGH;
	  HAL_Delay(1000);
////
////	  // Configure basic registers
////
	  ADS1247_write_register(REG_MUX0,1, (P_AIN0>>1)|N_AIN7);
//	  HAL_Delay(10);
	  uint8_t var=ADS1247_read_register(REG_MUX0,1);//optional for sanity check
//	  HAL_Delay(10);
//

//	  ADS1247_write_register(REG_MUX1,1,VREFCON1_ON | REFSELT1_ON);
	  ADS1247_write_register(REG_MUX1,1,0x08);
	  HAL_Delay(10);
	  var=ADS1247_read_register(REG_MUX1,1);////optional for sanity check
	  HAL_Delay(10);

	  ADS1247_write_register(REG_SYS0,1,PGA2_0 | DOR3_5);
	  var=ADS1247_read_register(REG_SYS0,1);////optional for sanity check
//	  HAL_Delay(10);
//	  ADS1247_write_register(REG_VBIAS,1,EN_BIAS_AIN0 | EN_BIAS_AIN1);

//	adc124xx_t ads={
//			.sel_channel_P=P_AIN0,
//			.sel_channel_N=P_AINCOM,
//			.sel_bias=DIS_BIAS_AINx,
//			.sel_dr=DOR3_5,
//			.sel_exc_mag=IMAG2_OFF,
//			.sel_exc_out=I1DIR_OFF|I2DIR_OFF,
//			.sel_internal_ref=VREFCON1_ON,
//			.sel_ref=REFSELT1_ON,
//			.sel_pga=PGA2_0,
//			.sel_sys_moniter=MUXCAL2_NORMAL
//	};
//	ads1247_init(&ads);


}


/**
  * @brief  :- write the adc cmd see @brief1
  *			cmd :- cmd to be write
  * 		return :- read adc conversion if sucess or -1 on fail
  */

uint8_t write_cmd(uint8_t cmd){
	CS_LOW;
	HAL_SPI_Transmit(&hspi1, &cmd,1, 2000);
	CS_HIGH;
	HAL_Delay(2);

	return 0;
}

double ads1247_raw_to_voltage(int32_t raw, float vref, uint8_t pga) {
    const uint32_t FULL_SCALE =8388608;  // 2^23

    return ((raw * (vref/pga) )/ FULL_SCALE);
}
double thermo_voltage(int32_t raw){
	const int32_t FULL_SCALE =8388608;  // 2^23
	double Voltage = (raw * (2.048 / 32)) / FULL_SCALE;

	return Voltage;

}
// ----- NIST ITS-90 for Type-T thermocouple -----

//static float T_type_C_to_mV(float tC) {
//    if (tC < -200.0f) tC = -200.0f;
//    if (tC >  400.0f) tC =  400.0f;
//
//    if (tC < 0.0f) {
//        const double a[] = {
//            0.000000000000E+00, 0.387481063640E-01, 0.441944343470E-04,
//            0.118443231050E-06, 0.200329735540E-07, 0.901380195590E-09,
//            0.226511565930E-10, 0.360711542050E-12, 0.384939398830E-14,
//            0.282135219250E-16, 0.142515947790E-18, 0.487686622860E-21,
//            0.107955392700E-23, 0.139450270620E-26, 0.797951539270E-30
//        };
//        double t = tC, tpow = 1.0, mv = 0.0;
//        for (int i=0;i<15;i++){ mv += a[i]*tpow; tpow*=t; }
//        return (float)mv;
//    } else {
//        const double a[] = {
//            0.000000000000E+00, 0.387481063640E-01, 0.332922278800E-04,
//            0.206182434040E-06, -0.218822568460E-08, 0.109968809280E-10,
//            -0.308157587720E-13, 0.454791352900E-16, -0.275129016730E-19
//        };
//        double t = tC, tpow = 1.0, mv = 0.0;
//        for (int i=0;i<9;i++){ mv += a[i]*tpow; tpow*=t; }
//        return (float)mv;
//    }
//}
//
//static float T_type_mV_to_C(float mV) {
//    if (mV < -5.603f) mV = -5.603f;
//    if (mV > 20.872f) mV = 20.872f;
//
//    if (mV < 0.0f) {
//        const double b[] = {
//            0.0000000E+00,  2.5949192E+01, -2.1316967E-01,
//            7.9018692E-01,  4.2527777E-01,  1.3304473E-01,
//            2.0241446E-02,  1.2668171E-03
//        };
//        double x=mV, xpow=1.0, t=0.0;
//        for (int i=0;i<8;i++){ t += b[i]*xpow; xpow*=x; }
//        return (float)t;
//    } else {
//        const double b[] = {
//            0.0000000E+00,  2.592800E+01, -7.602961E-01,
//            4.637791E-02,  -2.165394E-03,  6.048144E-05,
//            -7.293422E-07
//        };
//        double x=mV, xpow=1.0, t=0.0;
//        for (int i=0;i<7;i++){ t += b[i]*xpow; xpow*=x; }
//        return (float)t;
//    }
//}
//
//
//static float K_type_C_to_uV(float tC) {
//    const double *c;
//    int n = 10;
//
//    // Range -200°C to 0°C
//    const double K_fwd_neg200_0[10] = {
//        0.0,
//        3.9450128025e1,
//        2.3622373598e-2,
//       -3.2858906784e-4,
//       -4.9904828777e-6,
//       -6.7509059173e-8,
//       -5.7410327428e-10,
//       -3.1088872894e-12,
//       -1.0451609365e-14,
//       -1.9889266878e-17
//    };
//
//    // Range 0°C to 500°C
//    const double K_fwd_0_500[10] = {
//        0.0,
//        3.945013e1,
//        2.362237e-2,
//       -3.285890e-4,
//       -4.990483e-6,
//       -6.750906e-8,
//       -5.741033e-10,
//       -3.108887e-12,
//       -1.045161e-14,
//       -1.988927e-17
//    };
//
//    // Range 500°C to 1372°C
//    const double K_fwd_500_1372[10] = {
//        -0.118123,     // example c0, real coefficient from ITS-90
//         0.03945,      // c1
//         1.0e-6,       // c2
//         0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
//    };
//
//    if(tC < 0.0) {
//        c = K_fwd_neg200_0;
//
//    } else if(tC <= 500.0) {
//        c = K_fwd_0_500;
//    } else {
//        c = K_fwd_500_1372;
//    }
//
//    double E = 0.0;
//    double tpow = 1.0;
//    for(int i=0; i<n; i++)
//    {
//        E += c[i] * tpow;
//        tpow *= tC;
//    }
//
//    return E; // µV
//}
//
//double K_type_uV_to_C (double E_uV)
//{
//    const double *c;
//    int n = 10;
//
//    // Range 1: -200°C to 0°C  (E: -5891 µV to 0 µV)
//    const double K_inv_neg200_0[10] = {
//       0.0,               // c0
//       2.5173462e-2,      // c1
//      -1.1662878e-6,      // c2
//      -1.0833638e-9,      // c3
//      -8.9773540e-13,     // c4
//      -3.7342377e-16,     // c5
//      -8.6632643e-20,     // c6
//      -1.0450598e-23,     // c7
//      -5.1920577e-28,     // c8
//      -1.052755e-35       // c9
//    };
//
//    // Range 2: 0°C to 500°C  (E: 0 µV to 20644 µV)
//    const double K_inv_0_500[10] = {
//       0.0,               // c0
//       2.508355e-2,       // c1
//       7.860106e-8,       // c2
//      -2.503131e-10,      // c3
//       8.315270e-14,      // c4
//      -1.228034e-17,      // c5
//       9.804036e-22,      // c6
//      -4.413030e-26,      // c7
//       1.057734e-30,      // c8
//      -1.052755e-35       // c9
//    };
//
//    // Range 3: 500°C to 1372°C  (E: 20644 µV to 54886 µV)
//    const double K_inv_500_1372[10] = {
//      -1.318058e2,       // c0
//       4.830222e-2,      // c1
//      -1.646031e-6,      // c2
//       5.464731e-11,     // c3
//      -9.650715e-16,     // c4
//       8.802193e-21,     // c5
//      -3.110810e-26      // c6
//       // c7-c9 not given, assume 0
//    };
//    // Select coefficient array based on voltage
//    if(E_uV < 0.0) {
//        c = K_inv_neg200_0;
//    } else if(E_uV <= 20644.0) {
//        c = K_inv_0_500;
//    } else {
//        c = K_inv_500_1372;
//        n = 7; // only 7 coefficients provided
//    }
//
//    // Polynomial evaluation
//    double t = 0.0, E_power = 1.0;
//    for(int i=0; i<n; i++) {
//        t += c[i] * E_power;
//        E_power *= E_uV;
//    }
//
//    return t;
//}
//
//static float k_type_uV_to_C(float mV) {
//    if (mV < -5.603f) mV = -5.603f;
//    if (mV > 20.872f) mV = 20.872f;
//
//    if (mV < 0.0f) {
//        const double b[] = {
//            0.0000000E+00,  2.5949192E+01, -2.1316967E-01,
//            7.9018692E-01,  4.2527777E-01,  1.3304473E-01,
//            2.0241446E-02,  1.2668171E-03
//        };
//        double x=mV, xpow=1.0, t=0.0;
//        for (int i=0;i<8;i++){ t += b[i]*xpow; xpow*=x; }
//        return (float)t;
//    } else {
//        const double b[] = {
//            0.0000000E+00,  2.592800E+01, -7.602961E-01,
//            4.637791E-02,  -2.165394E-03,  6.048144E-05,
//            -7.293422E-07
//        };
//        double x=mV, xpow=1.0, t=0.0;
//        for (int i=0;i<7;i++){ t += b[i]*xpow; xpow*=x; }
//        return (float)t;
//    }
//}

float get_supply(float voltageReading, eMode_t conversion_mode){

	float retVal;

	retVal=voltageReading;
//	if(retVal<0.0f)return  0.0;


	switch(conversion_mode){

	case V0_5 :
		if(retVal>1.25f){
			retVal=5.0f;//todo undefine behavior have to set
		}
		else if(retVal<0.0f){
			retVal=0.0f;//todo undefine behavior have to set
		}
		else{
			retVal=retVal*4.0f;
		}

		break;

	case V0_10 :

		if(retVal>2.5f){
			retVal=10.0f;//todo undefine behavior have to set
		}
		else if(retVal<0.0f){
			retVal=0.0f;//todo undefine behavior have to set
		}
		else{
			retVal=retVal*4.0f;
		}


		break;
	case MV0_50 :
		        //voltageReading+=0.002f;
		        voltageReading=voltageReading-0.0008;
				retVal = (voltageReading)* 1000.0f;
				if(retVal>50.0f) retVal=50.0f;//todo undefine behavior have to set
				if(retVal<0.0f)   retVal=0.0f;//todo undefine behavior have to set

		break;


	case MV0_100 :
		voltageReading=voltageReading-0.0008;
		retVal = voltageReading * 1000.0f;
		if(retVal>100.0f) retVal=100.0f;//todo undefine behavior have to set
		if(retVal<0.0f)   retVal=0.0f;//todo undefine behavior have to set

		break;

	case MV0_250:
		voltageReading=voltageReading-0.0008;
		retVal = voltageReading * 1000.0f;
		if(retVal>250.0f) retVal=250.0f;//todo undefine behavior have to set
		if(retVal<0.0f)   retVal=0.0f;//todo undefine behavior have to set

		break;

	case MA0_20:

		retVal=(voltageReading*1000.0f/50.0f);//200ohm resistance and 4 scale 1000 for mv
        if (retVal > 20.0f) retVal = 20.0f;//todo undefine behavior have to set
        else if (retVal < 0.0f)  retVal = 0.0f;//todo undefine behavior have to set


		break;

	case MA4_20 :

		retVal=(voltageReading*1000.0f/50.0f);//200ohm resistance and 4 scale 1000 for mv

//		retVal=(voltageReading*1000.0f/250.0f)*4;//200ohm resistance and 4 scale 1000 for mv
        if (retVal > 20.0f) retVal = 20.0f;//todo undefine behavior have to set
        else if (retVal < 4.0f)  retVal = 0.0f;//todo undefine behavior have to set

		break;

	}


	return retVal;

}


