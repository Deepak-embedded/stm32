/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MODBUS485_H
#define __MODBUS485_H

#include <stdint.h>
#include "stm32f0xx_hal.h"

#define SID		   0//slave ID INDEX
#define FC		   1//Function Code INDEX
#define TOTAL_BYTE 2//TOTAL BYTE write INDEX
#define DATA_BYTE  3
#define TOTAL_REG_LEN 206
#define UART_RX_BUF_SIZE 26
#define CRC_LOW	6
#define CRC_HIGH	7
#define CMD_LEN   6 //CMD size excluding CRC of TWO byte
#define MB_ADDR_V0_5 0
#define MB_ADDR_V0_10   1
#define MB_ADDR_MV0_100 2
#define MB_ADDR_MV0_250 3
#define MB_ADDR_MA0_20	4
#define MB_ADDR_MA4_20  5
#define MB_WRITE_FC     0x10
#define MIN_CMD_LEN		25
#define ILLEGAL_FUNCTION       0x01
#define ILLEGAL_DATA_ADDRESS   0x02
#define ILLEGAL_DATA_VALUE     0x03

typedef enum{
	UINT32_T,
	UINT16_T
}TYPE_t;

typedef struct {
    uint8_t buffer[UART_RX_BUF_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
} RingBuffer_t;

extern uint8_t uart1RxData[UART_RX_BUF_SIZE];
extern uint8_t uart2RxData[UART_RX_BUF_SIZE];
extern uint8_t slave_id;
extern uint8_t data[UART_RX_BUF_SIZE];
extern uint32_t Holding_Registers_Database[100];
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart1;

uint16_t crc16(uint8_t *buffer, uint16_t buffer_length);
void writeHoldingRegs(TYPE_t datatype,UART_HandleTypeDef *huartx);
void sendData (uint8_t *data, int size,UART_HandleTypeDef *huartx );
#endif
